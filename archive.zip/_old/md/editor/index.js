export { default as Plain } from './serializer';
export { default as Raw } from './serializer/raw';
export { default as Slate } from './editor';
// import Editor from 'slate/lib/components/editor';
// export const Slate = Editor;
