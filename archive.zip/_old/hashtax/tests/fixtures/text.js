module.exports = `
#header @deco
#container
#bild {item.slug} color={item.farbe}#
qkwodqpowkd #bold asdiojqwdijqiowdj qiowdjoiqwd oiqwjd oiqwd j color={item.farbe}# qwdjoiqwio
Das ist ein Testqmwkd...
##
Test

#container
#content#
#

#footer
[Impressum](/impressum)
GesundheitsZentrum Kelkheim. #copyright 2017#.
#
#
`;
