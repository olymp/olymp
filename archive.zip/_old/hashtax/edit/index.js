import Slate from './editor';
export default Slate;
