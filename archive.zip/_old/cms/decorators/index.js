export { default as withFile } from './file';
export { default as withTemplates } from './templates';
export { default as withSettings } from './settings';
