export { default as PageModal } from './page';
