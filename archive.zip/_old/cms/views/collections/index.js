export { default } from './view';
