export { default as GZCardArtikel } from './artikel';
export { default as GZCardEinrichtung } from './einrichtung';
export { default as GZCardTermin } from './termin';
export { default as GZCard } from './text';
export { default as GZCardYoutube } from './youtube';
export { default as GZCardImage } from './image';
export { default as GZCardImages } from './images';
