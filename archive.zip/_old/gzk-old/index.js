import * as blocks from './blocks';

export * from './components';
export { default as Page } from './views/page';
export { default as Einrichtung } from './views/einrichtung';
export { default as News } from './views/news';
export { default as Artikel } from './views/artikel';
export const Blocks = blocks;
