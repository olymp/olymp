import { withAuth } from 'olymp';
export default withAuth;
