import React from 'react';
import { Stats } from '../views';

export default ({ query, pathname, router }) => <Stats />;
